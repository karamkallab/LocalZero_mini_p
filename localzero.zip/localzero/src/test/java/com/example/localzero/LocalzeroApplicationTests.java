package com.example.localzero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalzeroApplicationTests {

	@Test
	void contextLoads() {
	}

}
